package com.atmproject;

import java.util.Scanner;


public class AtmMain {
	static Scanner scan = new Scanner(System.in);

	public static void main(String[] args) {
		double depositAmount;
		double withdrawAmount;
		AtmOptions atmImp = new AtmOptions();
		Scanner scan = new Scanner(System.in);
		while (true) {
			System.out.println(" !!!!!!!Welcome Our ATM !!!!!!! ");
			System.out.println("****************DISPLAY MENU*****************");
			System.out.println("1)Pin");
			System.out.println("2)Check Available balance");
			System.out.println("3)Withdraw Amount");
			System.out.println("4)Deposit Amount");
			System.out.println("5)Mini Statement");
			System.out.println("6)Exit");
			System.out.println("**********************************************");
			int choice = scan.nextInt();
			switch (choice) {

			case 1:
				atmImp.validateUser();
				break;
			case 2:
				atmImp.viewBalance();
				break;
			case 3:
				System.out.println("Enter the Withdraw Amount : ");
				withdrawAmount = scan.nextDouble();
				atmImp.withDrawAmount(withdrawAmount);
				break;

			case 4:
				System.out.println("Enter  Amount to Deposit : ");
				depositAmount = scan.nextDouble();
				atmImp.depositAmount(depositAmount);
				break;
			case 5: atmImp.miniStatement();
			break;
			}

		}

	}
}
