package com.atmproject;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class AtmOptions {
	private static double balance;
	private static double depositAmount;
	private static double withdrawAmount;
	double amount;
	Map<Double, String> miniStatement = new HashMap<>();
	Scanner scan = new Scanner(System.in);

	public void validateUser() {

		System.out.println("Enter ATM Pin : ");
		int pin = scan.nextInt();

		System.out.println("Validated Your Pin");

	}

	public void viewBalance() {
		amount = amount + depositAmount - withdrawAmount;
		System.out.println("Current Available Balance :" + amount);
	}

	public void withDrawAmount(double withdrawAmount) {
		if (withdrawAmount > amount) {

			System.out.println("Insufficiant Balance!!!!");
			System.out.println("Available Balance  " + amount);
		} else {
			amount = amount - withdrawAmount;
			miniStatement.put(withdrawAmount, " Amount Withdraw");
			System.out.println("Afteramount withdraw available balance: " + amount);
		}
	}

	public void depositAmount(double depositAmount) {
		System.out.println(depositAmount + " ...Amount Deposited Successfuly... ");

		amount = amount + depositAmount;
		miniStatement.put(depositAmount, "Deposit Amount");
		System.out.println("    ");
		System.out.println("Your Account Balance after deposit :" + amount);

	}

	public void miniStatement() {
		for (Map.Entry<Double, String> m : miniStatement.entrySet()) {
			System.out.println(m.getKey() + " " + m.getValue());
		}
	}

}
